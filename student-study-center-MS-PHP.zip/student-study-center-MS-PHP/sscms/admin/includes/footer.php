
            <!-- Footer -->
            <footer class="footer">
              <p>Student Study Center Management System (SSCMS)</p>
            </footer>
            <!-- End Footer -->

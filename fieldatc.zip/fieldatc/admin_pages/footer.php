<div id="footer">
	<p style="color:white;font-size:14px;margin-left:10px; padding-top:15px;">Copyright &copy; 2014 St.Joseph University in Tanzania | Programmed By: <a href="http://tanzamo.com" style='color:white;'>Florian Kipeta</a></p>
</div>
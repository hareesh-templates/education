<?php
$conn=mysqli_connect('localhost','root','',"fieldatc");
if (!$conn) {
	echo "Your not connected to the database".mysqli_error();
}


?>
<div id="left">
	<div class="one">
		<b class="title">ADMISSION</b>
		<hr>
		<table align="center" width="100%" class="news">
			<tr>
			   <td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="online.php" target='_blank' class="admissionlinks">Apply Online</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="requirements.php" class="admissionlinks">Entry Requirement</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="download_form.php" class="admissionlinks">Download Form</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="reguration.php" class="admissionlinks">Admission Regulation</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="fees.php" class="admissionlinks">Fees & Financial <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Requirement</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="examination_reg.php" class="admissionlinks">Examination Reguration</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="appear_exams.php" class="admissionlinks">Appealing Examination</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="prospectus.php" class="admissionlinks">Student Prospectus</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="policy.php" class="admissionlinks">Academic Policy</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="scholarship.php" class="admissionlinks">Scholarship</a></td>
			</tr>
		</table>
	</div>
	<div class="two">
		<b class="title">CAMPUS TOUR</b>
		<hr>
		<table align="center" width="100%" class="news">
			<tr>
			   <td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="laboratories.php" class="admissionlinks">Laboratories</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="computers.php" class="admissionlinks">Computer Lab</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="workshop.php" class="admissionlinks">Workshop</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="library.php" class="admissionlinks">Library</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="hostel.php" class="admissionlinks">Hostel </a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="canteen.php" class="admissionlinks">Canteen </a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="medical.php" class="admissionlinks">Medical Facilities </a></td>
			</tr>
		</table>
	</div>
</div>
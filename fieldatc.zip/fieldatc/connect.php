<?php
$conn=mysqli_connect('localhost','root','','fieldatc');
if (!$conn) {
	echo "You are not connected to the database";
}
?>
THEME: Stack - Free Bootstrap Theme
AUTHOR: uiCookies.com
AUTHOR URI: https://uiCookies.com/


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

HTML5Shiv
https://github.com/aFarkas/html5shiv

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Stellar Parallax
http://markdalgleish.com/projects/stellar.js/

Owl Carousel
https://owlcarousel2.github.io/OwlCarousel2/

Flexslider
http://flexslider.woothemes.com/
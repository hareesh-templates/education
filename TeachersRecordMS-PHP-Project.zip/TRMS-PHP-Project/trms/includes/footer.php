        <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Teachers Record Management System <?php echo date('Y');?></div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="index.php">Home</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="about.php">About Us</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="contact.php">Contact</a>
                    </div>
                </div>
            </div>
        </footer>